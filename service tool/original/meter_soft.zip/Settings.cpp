#include <vcl.h>
#pragma hdrstop

#include "Settings.h"
#include "Main.h"

#pragma package(smart_init)
#pragma link "FloatEdit"
#pragma resource "*.dfm"
TSettingsForm *SettingsForm;

//---------------------------------------------------------------------------

__fastcall TSettingsForm::TSettingsForm(TComponent* Owner)
  : TForm(Owner)
{
}

//----------------------------- Form create: --------------------------------

void __fastcall TSettingsForm::FormCreate(TObject *Sender)
{
  cbAutoConnect->Checked = MainForm->FAutoConnect;
  cbAutoLoad->Checked = MainForm->FAutoLoad;
  feSample->Value = MainForm->FSample;
  if(MainForm->FSegs == 35) rb35->Checked = 1;
    else if(MainForm->FSegs == 40) rb40->Checked = 1;
      else rb50->Checked = 1;
}

//----------------------------- Form close: ---------------------------------

void __fastcall TSettingsForm::FormClose(TObject *Sender,
      TCloseAction &Action)
{
  if(ModalResult == mrOk)
  {
    MainForm->FAutoConnect = cbAutoConnect->Checked;
    MainForm->FAutoLoad = cbAutoLoad->Checked;
    MainForm->FSample = feSample->Value;
    if(rb35->Checked == 1) MainForm->FSegs = 35;
      else if(rb40->Checked == 1) MainForm->FSegs = 40;
        else MainForm->FSegs = 50;
  }
  Action = caFree;
  SettingsForm = NULL;
}

//------------------------------- ESC: --------------------------------------

void __fastcall TSettingsForm::FormKeyPress(TObject *Sender, char &Key)
{
  if (Key == VK_ESCAPE)
   ModalResult = mrCancel;
}

//-------------------------------- OK: --------------------------------------

void __fastcall TSettingsForm::btOkClick(TObject *Sender)
{
  ModalResult = mrOk;
}

//------------------------------ Cancel: ------------------------------------

void __fastcall TSettingsForm::btCancelClick(TObject *Sender)
{
  ModalResult = mrCancel;
}

//---------------------------------------------------------------------------

