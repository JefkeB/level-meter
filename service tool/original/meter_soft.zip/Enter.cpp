#include <vcl.h>
#pragma hdrstop

#include "Enter.h"
#include "Main.h"

#pragma package(smart_init)
#pragma link "FloatEdit"
#pragma resource "*.dfm"
TEnterForm *EnterForm;

//---------------------------------------------------------------------------

__fastcall TEnterForm::TEnterForm(TComponent* Owner)
  : TForm(Owner)
{
}

//---------------------------------------------------------------------------

void __fastcall TEnterForm::FormClose(TObject *Sender,
      TCloseAction &Action)
{
  Action = caFree; EnterForm = 0;
}

//---------------------------------------------------------------------------

void __fastcall TEnterForm::FormShow(TObject *Sender)
{
  int led1 = MainForm->FRow - 1;
  int led2 = MainForm->FRowE - 1;
  int c = MainForm->Leds[led1].color;
  int h = MainForm->Leds[led1].en? 1 : 0;
  double d = MainForm->Leds[led1].dB;
  double d1 = d;
  for(int i = led1; i <= led2; i++)
  {
    if(MainForm->Leds[i].color != c) c = COLORS - 1;
    if(MainForm->Leds[i].en != h) h = 2;
    if(MainForm->Leds[i].dB != d) d = -100;
  }
  rgColor->ItemIndex = c;
  rgLabel->ItemIndex = h;
  if(d > -100) { feData->Enabled = 1; feData->Value = d; cbNodB->Checked = 0; }
    else { feData->Enabled = 0; feData->Value = d1; cbNodB->Checked = 1; }
}

//---------------------------------------------------------------------------

void __fastcall TEnterForm::cbNodBClick(TObject *Sender)
{
  feData->Enabled = !cbNodB->Checked;
}

//---------------------------------------------------------------------------

void __fastcall TEnterForm::btOkClick(TObject *Sender)
{
  MainForm->NewColor = rgColor->ItemIndex;
  MainForm->NewEn = rgLabel->ItemIndex;
  MainForm->NewdB = cbNodB->Checked? -100 : feData->Value;
}

//---------------------------------------------------------------------------

void __fastcall TEnterForm::FormKeyPress(TObject *Sender, char &Key)
{
  if (Key == VK_ESCAPE) btCancel->Click();
  if (Key == VK_RETURN) btOk->Click();
}

//---------------------------------------------------------------------------

