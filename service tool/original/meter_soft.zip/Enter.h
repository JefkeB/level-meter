#ifndef EnterH
#define EnterH

#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "FloatEdit.hpp"
#include <ExtCtrls.hpp>

//---------------------------------------------------------------------------

class TEnterForm : public TForm
{
__published:	// IDE-managed Components
  TButton *btCancel;
  TButton *btOk;
  TGroupBox *GroupBox2;
  TFloatEdit *feData;
  TLabel *Label1;
  TRadioGroup *rgColor;
  TRadioGroup *rgLabel;
  TCheckBox *cbNodB;
  void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
  void __fastcall btOkClick(TObject *Sender);
  void __fastcall FormShow(TObject *Sender);
  void __fastcall FormKeyPress(TObject *Sender, char &Key);
  void __fastcall cbNodBClick(TObject *Sender);
private:	// User declarations
  int Value;
public:		// User declarations
  __fastcall TEnterForm(TComponent* Owner);
};

//---------------------------------------------------------------------------

extern PACKAGE TEnterForm *EnterForm;

//---------------------------------------------------------------------------

#endif
