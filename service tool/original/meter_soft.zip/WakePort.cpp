#pragma hdrstop

#include "WakePort.h"

#pragma package(smart_init)

//--------------------------- �����������: ----------------------------------

__fastcall TWakePort::TWakePort()
{
  SetBaudRate(BAUD_RATE);
}

//---------------------------- ����������: ----------------------------------

__fastcall TWakePort::~TWakePort()
{
//
}

//---------------------------------------------------------------------------
//------------------------- ����������� �������: ----------------------------
//---------------------------------------------------------------------------

//---------------------------- CMD_SET_PRESET: --------------------------------

void __fastcall TWakePort::SetPreset(int p)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_SET_PRESET, "SetPreset");
  AddByte(p);
  SetTo(LONG_RX_TIMEOUT, DEFAULT_TX_TIMEOUT);
  SendCmd();
  SetTo(DEFAULT_RX_TIMEOUT, DEFAULT_TX_TIMEOUT);
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_GET_PRESET: --------------------------------

void __fastcall TWakePort::GetPreset(int &p)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_GET_PRESET, "GetPreset");
  SendCmd();
  p = GetByte();
  _LEAVE_COMMAND(CmdCrSec)
}

//--------------------------- CMD_SET_MODE: ------------------------------

void __fastcall TWakePort::SetDispMode(int m)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_SET_MODE, "SetDispMode");
  AddByte(m);
  SendCmd();
  _LEAVE_COMMAND(CmdCrSec)
}

//----------------------------- CMD_GET_MODE: --------------------------------

void __fastcall TWakePort::GetDispMode(int &m)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_GET_MODE, "GetDispMode");
  SendCmd();
  m = GetByte();
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_GET_METER: ---------------------------------

void __fastcall TWakePort::GetMeter(int *v)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_GET_METER, "GetMeter");
  SendCmd();
  for(int i = 0; i < DATA_BUFF; i++)
    v[i] = GetWord();
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_RES_STAT: ---------------------------------

void __fastcall TWakePort::ResetStat(void)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_RES_STAT, "ResetStat");
  SendCmd();
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_SET_PARAMS: ---------------------------------

void __fastcall TWakePort::SetParams(params_t p1, params_t p2)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_SET_PARAMS, "SetParams");

  AddWord(p1.integ);
  AddWord(p1.decay);
  AddWord(p1.scale);
  AddWord(p1.resp);
  AddWord(p1.fall);
  AddWord(p1.hold);
  AddWord(p1.mfall);
  AddWord(p1.mhold);

  AddWord(p2.integ);
  AddWord(p2.decay);
  AddWord(p2.scale);
  AddWord(p2.resp);
  AddWord(p2.fall);
  AddWord(p2.hold);
  AddWord(p2.mfall);
  AddWord(p2.mhold);

  SendCmd();
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_GET_PARAMS: ---------------------------------

void __fastcall TWakePort::GetParams(params_t &p1, params_t &p2)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_GET_PARAMS, "GetParams");
  SendCmd();

  p1.integ = GetWord();
  p1.decay = GetWord();
  p1.scale = GetWord();
  p1.resp  = GetWord();
  p1.fall  = GetWord();
  p1.hold  = GetWord();
  p1.mfall = GetWord();
  p1.mhold = GetWord();

  p2.integ = GetWord();
  p2.decay = GetWord();
  p2.scale = GetWord();
  p2.resp  = GetWord();
  p2.fall  = GetWord();
  p2.hold  = GetWord();
  p2.mfall = GetWord();
  p2.mhold = GetWord();

  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_SET_TABLE: ---------------------------------

void __fastcall TWakePort::SetTable(int *t)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_SET_TABLE, "SetTable");
  for(int i = 0; i < SEGS; i++)
    AddWord(t[i]);
  SendCmd();
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_GET_TABLE: ---------------------------------

void __fastcall TWakePort::GetTable(int *t)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_GET_TABLE, "GetTable");
  SendCmd();
  for(int i = 0; i < SEGS; i++)
    t[i] = (int16_t)GetWord();
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_SET_LEDS: ---------------------------------

void __fastcall TWakePort::SetLeds(int m, int bm, int bs, int n)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_SET_LEDS, "SetLeds");
  AddByte(m);
  AddByte(bm);
  AddByte(bs);
  AddWord(n);
  SendCmd();
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_GET_LEDS: ---------------------------------

void __fastcall TWakePort::GetLeds(int &m, int &bm, int &bs, int &n)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_GET_LEDS, "GetLeds");
  SendCmd();
  m = GetByte();
  bm = GetByte();
  bs = GetByte();
  n = GetWord();
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_EE_SAVE: ---------------------------------

void __fastcall TWakePort::EESave(void)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_EE_SAVE, "EESave");
  SetTo(LONG_RX_TIMEOUT, DEFAULT_TX_TIMEOUT);
  SendCmd();
  SetTo(DEFAULT_RX_TIMEOUT, DEFAULT_TX_TIMEOUT);
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_DEFAULT: ---------------------------------

void __fastcall TWakePort::Default(void)
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_DEFAULT, "Default");
  SendCmd();
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------- CMD_TEST: ---------------------------------

void __fastcall TWakePort::Test(uint32_t &t) //TODO:
{
  _ENTER_COMMAND(CmdCrSec)
  NewCmd(CMD_TEST, "Test");
  SendCmd();
  t = GetDWord();
  _LEAVE_COMMAND(CmdCrSec)
}

//---------------------------------------------------------------------------

