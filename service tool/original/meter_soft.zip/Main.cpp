#include <vcl.h>
#include <fstream> 
#include <iostream.h>
#include <math.h>
#include <dir.h>
#pragma hdrstop

#include "Main.h"
#include "Connect.h"
#include "About.h"
#include "Settings.h"
#include "Const.h"
#include "Enter.h"

#pragma package(smart_init)
#pragma link "ThemeMgr"
#pragma resource "*.dfm"
TMainForm *MainForm;

//---------------------------------------------------------------------------

__fastcall TMainForm::TMainForm(TComponent* Owner)
        : TForm(Owner)
{
}

//-------------------------- �������� �����: --------------------------------

void __fastcall TMainForm::FormCreate(TObject *Sender)
{ int i;
  //����� ���������:
  Caption = Application->Title;      //��������� ����������
  DecimalSeparator = '.';            //���������� �����������
  FFileName = "";
  //��������� DoubleBuffered ��� �����������:
  MainForm->DoubleBuffered = 1;
  ToolBar->DoubleBuffered = 1;
  BlockPanel->DoubleBuffered = 1;
  Panel1A->DoubleBuffered = 1;
  Panel1B->DoubleBuffered = 1;
  BarPanel->DoubleBuffered = 1;
  Panel2A->DoubleBuffered = 1;
  Panel2B->DoubleBuffered = 1;
  IndPanel->DoubleBuffered = 1;
  Panel4A->DoubleBuffered = 1;
  Panel4B->DoubleBuffered = 1;
  TabPanel->DoubleBuffered = 1;
  sgLogTable->DoubleBuffered = 1;
  CtrlPanel->DoubleBuffered = 1;
  StatusBar->DoubleBuffered = 1;
  //���������� ������ �����������:
  Colors[0] = (TColor)RGB(255,255,255); //�����
  Colors[1] = (TColor)RGB(220,40,0);    //�������
  Colors[2] = (TColor)RGB(255,153,51);  //���������
  Colors[3] = (TColor)RGB(255,220,0);   //������
  Colors[4] = (TColor)RGB(0,180,40);    //�������
  Colors[5] = (TColor)RGB(102,102,255); //�����
  Colors[6] = (TColor)RGB(50,50,50);    //����� (OFF)
  //��������� ����� � �����������:
  WakePort = new TWakePort();
  acDisconnectExecute(NULL);
  //������ �����������:
  Labels = new TComponentList();
  LedsL = new TComponentList();
  LedsR = new TComponentList();
  FillLists();
  //��������� �������:
  sgLogTable->Rows[0]->CommaText =
    "LED#,Color,dB,Code";
  sgLogTable->PopupMenu = PopupMenu1;
  //������ ������������:
  Lock = 1;
  ReadConfig();
  SetSegsCount();
  FPreset = 0;
  FDispMode = 0;
  FLedsSet = 0;
  Lock = 0;
  //������� �����:
  Disconnect();
  //���������� �������:
  Timer1->Interval = FSample;
  Timer1->Enabled = 1;
}

//-------------------------- �������� �����: --------------------------------

void __fastcall TMainForm::FormClose(TObject *Sender, TCloseAction &Action)
{
  if(MeterThread)
  {
    MeterThread->Terminate(); //��������� ������
    MeterThread->WaitFor();   //������� ���������� ����������
    delete MeterThread;       //�������� ������
    MeterThread = NULL;
  }
  SaveConfig();
  Disconnect();
  delete Labels;
  delete LedsL;
  delete LedsR;
}

//------------------------------ Resize: ------------------------------------

void __fastcall TMainForm::FormResize(TObject *Sender)
{
  int up = ToolBar->Top + ToolBar->Height;
  int dn = CtrlPanel->Top - IndPanel->Height;
  IndPanel->Top = dn;
  int addy = dn - up - BlockPanel->Constraints->MinHeight - BarPanel->Constraints->MinHeight;
  if(addy < 0) addy = 0;
  BlockPanel->Height = BlockPanel->Constraints->MinHeight + addy / 2;
  BarPanel->Height = BarPanel->Constraints->MinHeight + (addy + 1) / 2;
  BarPanel->Top = IndPanel->Top - BarPanel->Height;
  BlockPanel->Top = BarPanel->Top - BlockPanel->Height;

  BlockPanel->Width = TabPanel->Left;
  BarPanel->Width = TabPanel->Left;
  IndPanel->Width = TabPanel->Left;

	Panel1B->Left = (BlockPanel->ClientWidth - Panel1B->Width)/2;
	Panel1B->Top  = (BlockPanel->ClientHeight - Panel1B->Height)/2;
	Panel2B->Left = (BarPanel->ClientWidth - Panel2B->Width)/2;
	Panel2B->Top  = (BarPanel->ClientHeight - Panel2B->Height)/2;
	Panel4B->Left = (IndPanel->ClientWidth - Panel4B->Width)/2;
}

//------------------------- ������ INI-�����: -------------------------------

void __fastcall TMainForm::ReadConfig(void)
{
  TMemIniFile *ini;
  ini = new TMemIniFile(ChangeFileExt(Application->ExeName,".ini" ));
  Left = ini->ReadInteger("General","Left",Left);
  Top = ini->ReadInteger("General","Top",Top);
  Width = ini->ReadInteger("General","Width",Width);
  Height = ini->ReadInteger("General","Height",Height);
  WindowState = TWindowState(ini->ReadInteger("General", "WindowState", WindowState));
  FDataDir = ini->ReadString("General","DataDir",ExtractFilePath(ParamStr(0)));
  FPortNumber = ini->ReadInteger("General","Port",0);
  FAutoConnect = ini->ReadBool("Settings","AutoConnect",1);
  FAutoLoad = ini->ReadBool("Settings","AutoLoad",1);
  FSample = ini->ReadInteger("Settings","Update",300);
  FSegs = ini->ReadInteger("Settings","Segments",50);
  if((FSegs != 35) && (FSegs != 40)) FSegs = 50;
  //LEDs Parameters:
  for(int i = 0; i < SEGS; i++)
  {
    Leds[i].color = ini->ReadInteger("Leds Colors", "Led" + IntToStr(i + 1), 1);
    Leds[i].en = ini->ReadBool("Leds En", "Led" + IntToStr(i + 1), 0);
  }
  delete ini;
}

//----------------------- ���������� INI-�����: -----------------------------

void __fastcall TMainForm::SaveConfig(void)
{
  TMemIniFile *ini;
  ini = new TMemIniFile(ChangeFileExt(Application->ExeName,".ini" ));
  ini->WriteInteger("General", "WindowState", WindowState);
  if (WindowState != wsMaximized)
   { ini->WriteInteger("General","Left",Left);
     ini->WriteInteger("General","Top",Top);
     ini->WriteInteger("General","Width",Width);
     ini->WriteInteger("General","Height",Height);
   }
  ini->WriteString("General","DataDir",ExtractRelativePath(ParamStr(0),FDataDir));
  ini->WriteInteger("General","Port",FPortNumber);
  ini->WriteBool("Settings","AutoConnect",FAutoConnect);
  ini->WriteBool("Settings","AutoRead",FAutoLoad);
  ini->WriteInteger("Settings","Update",FSample);
  ini->WriteInteger("Settings","Segments",FSegs);
  //LEDs Parameters:
  for(int i = 0; i < SEGS; i++)
  {
    ini->WriteInteger("Leds Colors", "Led" + IntToStr(i + 1), Leds[i].color);
    ini->WriteBool("Leds En", "Led" + IntToStr(i + 1), Leds[i].en);
  }
  try { ini->UpdateFile(); } catch (Exception &E)
   { MessageDlg(E.Message, mtError, TMsgDlgButtons() << mbOK, 0); }
  delete ini;
}

//------------------------ ��������� ����� ������: --------------------------

void __fastcall TMainForm::SetSegsCount(void)
{
  sgLogTable->RowCount = FSegs + 1;
  for(int i = 1; i <= FSegs; i++)
    sgLogTable->Cells[0][i] = IntToStr(i);
  FillTable();
  for(int i = 0; i < SEGS; i++)
  {
    TShape *SegL = dynamic_cast<TShape*>(LedsL->Items[i]);
    TShape *SegR = dynamic_cast<TShape*>(LedsR->Items[i]);
    SegL->Visible = i < FSegs;
    SegR->Visible = i < FSegs;
  }
  DrawScale();
  ClearMeter();
  ClearStatus();
}

//---------------------------------------------------------------------------
//------------------------------ Menus: -------------------------------------
//---------------------------------------------------------------------------

//---------------------------- Menu Exit: -----------------------------------

void __fastcall TMainForm::acExitExecute(TObject *Sender)
{
  Close();
}

//----------------------------- Connect: ------------------------------------

void __fastcall TMainForm::acConnectExecute(TObject *Sender)
{
  try
  {
    Timer1->Enabled = 0;
    if(!ConnectForm) ConnectForm = new TConnectForm(Application, &FPortNumber);
    if(ConnectForm->ShowModal() == mrOk)
    {
      Disconnect();
      Connect();
    }
  }
  __finally { Timer1->Enabled = 1; }
}

void __fastcall TMainForm::Connect(void)
{
  try
  {
    WakePort->Open(FPortNumber);
    FPortName = WakePort->PortName;
    FDeviceName = WakePort->GetInfo(0);
    AnsiString name = DEVICE_NAME;
    FConnected = FDeviceName.SubString(1, name.Length()) == name;
    if(!FConnected) throw EInOutError("Unknown device");
    StatusBar->Panels->Items[0]->Text = " ON LINE: " +
      FDeviceName + " (" + FPortName + ") ";
    Timer1->Interval = FSample;
    MeterThread = new TMeterThread();
    MeterThread->SetStarted(1);
    //�������������� ������ ����������:
    if(FAutoLoad) acReadExecute(NULL);
  }
  catch(const EInOutError &e)
  {
    Disconnect();
  }
}

//---------------------------- Disconnect: ----------------------------------

void __fastcall TMainForm::acDisconnectExecute(TObject *Sender)
{
  Timer1->Enabled = 0;
  FPortNumber = 0;
  Disconnect();
}

void __fastcall TMainForm::Disconnect(void)
{
  if(MeterThread)
  {
    MeterThread->Terminate();
    MeterThread->WaitFor();
    delete MeterThread;
    MeterThread = NULL;
    ClearMeter();
    ClearStatus();
  }
  WakePort->Close();
  FConnected = 0;
  FPortName = "";
  FDeviceName = "";
  if(FPortNumber) StatusBar->Panels->Items[0]->Text = " CONNECTING... ";
    else StatusBar->Panels->Items[0]->Text = " OFF LINE ";
}

//---------------------------- Read Params: ---------------------------------

void __fastcall TMainForm::acReadExecute(TObject *Sender)
{
  if(FConnected && !Lock)
  {
    Lock = 1;
    int m, bm, bs, n;
    //read preset number:
    WakePort->GetPreset(FPreset);
    cbPreset->ItemIndex = FPreset;
    //read display mode:
    WakePort->GetDispMode(m);
    cbDispBar->Checked     = m & DP_BAR;
    cbDispPeak->Checked    = m & DP_PEAK;
    cbDispMaxBar->Checked  = m & DP_BARMAX;
    cbDispMaxPeak->Checked = m & DP_PEAKMAX;
    cbStat->Checked        = m & DP_ABSMAX;
    FDispMode = m;
    ClearStatus();
    //read meter params:
    params_t p1, p2;
    WakePort->GetParams(p1, p2);

    feInteg1e->Value = p1.integ / 10.0;
    feInteg1u->Value = feInteg1e->Value / INTEG_TTAU;
    feResp1e->Value  = p1.resp;
    feResp1u->Value  = feResp1e->Value / RESP_TTAU;
    feHold1e->Value  = p1.hold;
    feHold1u->Value  = feHold1e->Value;
    feDecay1e->Value = p1.decay;
    feDecay1u->Value = feDecay1e->Value / DECAY_TTAU;
    feMHold1e->Value = p1.mhold;
    feMHold1u->Value = feMHold1e->Value;
    feFall1e->Value  = p1.fall;
    feFall1u->Value  = feFall1e->Value / FALL_TTAU;
    feMFall1e->Value = p1.mfall;
    feMFall1u->Value = feMFall1e->Value / FALL_TTAU;
    feScale1e->Value = p1.scale / 1000.0;
    feScale1u->Value = feScale1e->Value;

    feInteg2e->Value = p2.integ / 10.0;
    feInteg2u->Value = feInteg2e->Value / INTEG_TTAU;
    feResp2e->Value  = p2.resp;
    feResp2u->Value  = feResp2e->Value / RESP_TTAU;
    feHold2e->Value  = p2.hold;
    feHold2u->Value  = feHold2e->Value;
    feDecay2e->Value = p2.decay;
    feDecay2u->Value = feDecay2e->Value / DECAY_TTAU;
    feMHold2e->Value = p2.mhold;
    feMHold2u->Value = feMHold2e->Value;
    feFall2e->Value  = p2.fall;
    feFall2u->Value  = feFall2e->Value / FALL_TTAU;
    feMFall2e->Value = p2.mfall;
    feMFall2u->Value = feMFall2e->Value / FALL_TTAU;
    feScale2e->Value = p2.scale / 1000.0;
    feScale2u->Value = feScale2e->Value;
    //read dB table:
    int table[SEGS];
    WakePort->GetTable(table);
    for(int i = 0; i < SEGS; i++)
      Leds[i].dB = table[i] / 100.0;
    FillTable();
    DrawScale();
    //read LEDs params:
    WakePort->GetLeds(m, bm, bs, n);
    cbBrm->ItemIndex = m;
    feBrMeter->Value = bm;
    feBrScale->Value = bs;
    cbLED0->Checked  = n & TR0;
    cbLED1->Checked  = n & TR1;
    cbLED2->Checked  = n & TR2;
    cbLED3->Checked  = n & TR3;
    cbLED4->Checked  = n & TR4;
    cbLED5->Checked  = n & TR5;
    cbLED6->Checked  = n & TR6;
    cbLED7->Checked  = n & TR7;
    cbLED8->Checked  = n & TR8;
    cbLED8->Checked  = n & TR9;
    cbScale->Checked = n & SCALE;
    FLedsSet = n;
    Lock = 0;
  }
}

//--------------------------- Write Params: ---------------------------------

void __fastcall TMainForm::acWriteExecute(TObject *Sender)
{
  if(FConnected)
  {
    //write preset number:
    cbPresetChange(NULL);
    //write display mode:
    cbDispBarClick(NULL);
    //write meter params:
    feInteg1eChanged(NULL);
    //write dB table:
    WriteTable();
    //write LEDs params:
    cbLED0Click(NULL);
  }
}

//--------------------------- Save to EEPROM: -------------------------------

void __fastcall TMainForm::acEepromExecute(TObject *Sender)
{
  if(FConnected)
  {
    TCursor Save_Cursor = Screen->Cursor;
    try
    {
      Screen->Cursor = crHourGlass;
      acWriteExecute(NULL);
      WakePort->EESave();
    }
    __finally
    {
      Screen->Cursor = Save_Cursor;
    }
  }
}

//--------------------------- Load Defaults: --------------------------------

void __fastcall TMainForm::acDefaultExecute(TObject *Sender)
{
  int Ans = MessageDlg("Are you sure to load the default values?",
              mtConfirmation, TMsgDlgButtons() << mbYes << mbNo, 0);
  if(Ans == IDYES)
  {
    WakePort->Default();
    acReadExecute(NULL);
    //acWriteExecute(NULL);
  }
}

//---------------------------- Open Preset: ---------------------------------

void __fastcall TMainForm::acPreOpenExecute(TObject *Sender)
{
  //��������� ����������, ����� ����� "���������" Windows
  //����������������� ��������� �� ���������
  DecimalSeparator = '.';
  //���������� ����� �������:
  OpenDialog->Title = "Open Preset File";
  OpenDialog->InitialDir = FDataDir;
  OpenDialog->FileName = "";
  OpenDialog->Filter = "Preset file (*.pre)|*.pre|All files (*.*)|*.*";
  OpenDialog->DefaultExt = "par";
  //����� ������� "Open Params...":
  if(!OpenDialog->Execute()) return;
  //���������� ����:
  FDataDir = ExtractFilePath(OpenDialog->FileName);
  //������ ����� ����������:
  TMemIniFile *ini;
  ini = new TMemIniFile(OpenDialog->FileName);

  Lock = 1;
  try
  {
    //Display Mode:
    FDispMode  = ini->ReadInteger("Display", "Mode", DP_BAR + DP_PEAK);
    cbDispBar->Checked     = FDispMode & DP_BAR;
    cbDispPeak->Checked    = FDispMode & DP_PEAK;
    cbDispMaxBar->Checked  = FDispMode & DP_BARMAX;
    cbDispMaxPeak->Checked = FDispMode & DP_PEAKMAX;
    cbStat->Checked        = FDispMode & DP_ABSMAX;
    //Bar Parameters:
    feInteg1e->Value  = ini->ReadFloat("Bar Params", "T_integration", 5.0);
    feDecay1e->Value  = ini->ReadFloat("Bar Params", "T_decay", 1700.0);
    feScale1e->Value  = ini->ReadFloat("Bar Params", "Scale", 1.0);
    feResp1e->Value   = ini->ReadFloat("Bar Params", "T_response", 100.0);
    feFall1e->Value   = ini->ReadFloat("Bar Params", "T_fall", 1700.0);
    feHold1e->Value   = ini->ReadFloat("Bar Params", "T_hold", 20.0);
    feMFall1e->Value  = ini->ReadFloat("Bar Params", "T_max_fall", 0.0);
    feMHold1e->Value  = ini->ReadFloat("Bar Params", "T_max_hold", 0.0);
    //Peak Parameters:
    feInteg2e->Value  = ini->ReadFloat("Peak Params", "T_integration", 0.0);
    feDecay2e->Value  = ini->ReadFloat("Peak Params", "T_decay", 0.0);
    feScale2e->Value  = ini->ReadFloat("Peak Params", "Scale", 1.0);
    feResp2e->Value   = ini->ReadFloat("Peak Params", "T_response", 100.0);
    feFall2e->Value   = ini->ReadFloat("Peak Params", "T_fall", 600.0);
    feHold2e->Value   = ini->ReadFloat("Peak Params", "T_hold", 1000.0);
    feMFall2e->Value  = ini->ReadFloat("Peak Params", "T_max_fall", 0.0);
    feMHold2e->Value  = ini->ReadFloat("Peak Params", "T_max_hold", 0.0);
    //dB Table:
    for(int i = 0; i < SEGS; i++)
      Leds[i].dB = ini->ReadFloat("dB Table", "Led" + IntToStr(i + 1), i - SEGS + 1);
    //LEDs Parameters:
    cbBrm->ItemIndex = ini->ReadInteger("LEDs", "BrMode", BRM_VR);
    feBrMeter->Value = ini->ReadInteger("LEDs", "BrMeter", 100);
    feBrScale->Value = ini->ReadInteger("LEDs", "BrScale", 100);
    FLedsSet = ini->ReadInteger("LEDs", "LedsSet", TR1 + TR4 + TR7 + SCALE);
    cbLED0->Checked  = FLedsSet & TR0;
    cbLED1->Checked  = FLedsSet & TR1;
    cbLED2->Checked  = FLedsSet & TR2;
    cbLED3->Checked  = FLedsSet & TR3;
    cbLED4->Checked  = FLedsSet & TR4;
    cbLED5->Checked  = FLedsSet & TR5;
    cbLED6->Checked  = FLedsSet & TR6;
    cbLED7->Checked  = FLedsSet & TR7;
    cbLED8->Checked  = FLedsSet & TR8;
    cbLED8->Checked  = FLedsSet & TR9;
    cbScale->Checked = FLedsSet & SCALE;
  }
  __finally
  {
    Lock = 0;
    delete ini;
    ClearStatus(); //������� ������ �������
    FillTable();   //���������� �������
    DrawScale();   //����� �����
    acWriteExecute(NULL); //�������� ���������� � ����������
  }
}

//---------------------------- Save Preset: ---------------------------------

void __fastcall TMainForm::acPreSaveExecute(TObject *Sender)
{
  //��������� ����������, ����� ����� "���������" Windows
  //����������������� ��������� �� ���������
  DecimalSeparator = '.';
  //���������� ����� �������:
  SaveDialog->Title = "Save Preset File";
  SaveDialog->InitialDir = FDataDir;
  SaveDialog->FileName = "Preset1";
  SaveDialog->Filter = "Preset file (*.pre)|*.pre|All files (*.*)|*.*";
  SaveDialog->DefaultExt = "par";
  //����� ������� "Save Params...":
  if(!SaveDialog->Execute()) return;
  //���������� ����:
  FDataDir = ExtractFilePath(SaveDialog->FileName);
  //���������� ����� ����������:
  TMemIniFile *ini;
  ini = new TMemIniFile(SaveDialog->FileName);

  //Display Mode:
  ini->WriteInteger("Display", "Mode", FDispMode);
  //Bar Parameters:
  ini->WriteFloat("Bar Params", "T_integration", feInteg1e->Value);
  ini->WriteFloat("Bar Params", "T_decay", feDecay1e->Value);
  ini->WriteFloat("Bar Params", "Scale", feScale1e->Value);
  ini->WriteFloat("Bar Params", "T_response", feResp1e->Value);
  ini->WriteFloat("Bar Params", "T_fall", feFall1e->Value);
  ini->WriteFloat("Bar Params", "T_hold", feHold1e->Value);
  ini->WriteFloat("Bar Params", "T_max_fall", feMFall1e->Value);
  ini->WriteFloat("Bar Params", "T_max_hold", feMHold1e->Value);
  //Peak Parameters:
  ini->WriteFloat("Peak Params", "T_integration", feInteg2e->Value);
  ini->WriteFloat("Peak Params", "T_decay", feDecay2e->Value);
  ini->WriteFloat("Peak Params", "Scale", feScale2e->Value);
  ini->WriteFloat("Peak Params", "T_response", feResp2e->Value);
  ini->WriteFloat("Peak Params", "T_fall", feFall2e->Value);
  ini->WriteFloat("Peak Params", "T_hold", feHold2e->Value);
  ini->WriteFloat("Peak Params", "T_max_fall", feMFall2e->Value);
  ini->WriteFloat("Peak Params", "T_max_hold", feMHold2e->Value);
  //dB Table:
  for(int i = 0; i < SEGS; i++)
  ini->WriteFloat("dB Table", "Led" + IntToStr(i + 1), Leds[i].dB);
  //LEDs Parameters:
  ini->WriteInteger("LEDs", "BrMode", cbBrm->ItemIndex);
  ini->WriteInteger("LEDs", "BrMeter", feBrMeter->Value);
  ini->WriteInteger("LEDs", "BrScale", feBrScale->Value);
  ini->WriteInteger("LEDs", "LedsSet", FLedsSet);

  try { ini->UpdateFile(); } catch (Exception &E)
   { MessageDlg(E.Message, mtError, TMsgDlgButtons() << mbOK, 0); }
  delete ini;
}

//---------------------------- Menu Settings: -------------------------------

void __fastcall TMainForm::acSettingsExecute(TObject *Sender)
{
  if(!SettingsForm) SettingsForm = new TSettingsForm(Application);
  SettingsForm->ShowModal();
  Timer1->Interval = FSample;
  SetSegsCount();
  //�������������� �������� ����������:
  if(FAutoLoad) acReadExecute(NULL);
}

//---------------------------- Menu About: ----------------------------------

void __fastcall TMainForm::acAboutExecute(TObject *Sender)
{
  if(!AboutForm) AboutForm = new TAboutForm(Application);
  AboutForm->ShowModal();
}

//---------------------------------------------------------------------------
//---------------------------- ����������: ----------------------------------
//---------------------------------------------------------------------------

//--------------------------- ����� �������: --------------------------------

void __fastcall TMainForm::cbPresetChange(TObject *Sender)
{
  if(!Lock)
  {
    WakePort->SetPreset(cbPreset->ItemIndex);
  }
}

//------------------- ���������� �������� �����������: ----------------------

void __fastcall TMainForm::cbDispBarClick(TObject *Sender)
{
  if(!Lock)
  {
    int m = 0;
    if(cbDispBar->Checked)     m = m + DP_BAR;
    if(cbDispPeak->Checked)    m = m + DP_PEAK;
    if(cbDispMaxBar->Checked)  m = m + DP_BARMAX;
    if(cbDispMaxPeak->Checked) m = m + DP_PEAKMAX;
    if(cbStat->Checked)        m = m + DP_ABSMAX;
    FDispMode = m;
    WakePort->SetDispMode(FDispMode);
    ClearStatus();
  }
}

//------------------------- ����� ����������: -------------------------------

void __fastcall TMainForm::btResetClick(TObject *Sender)
{
  if(!Lock)
  {
    WakePort->ResetStat();
  }
}

//----------------------------- ������� T: ----------------------------------

void __fastcall TMainForm::feInteg1eChanged(TObject *Sender)
{
  if(!Lock)
  {
    Lock = 1;
    params_t p1, p2;

    p1.integ = feInteg1e->Value * 10.0;
    feInteg1u->Value = feInteg1e->Value / INTEG_TTAU;
    p1.resp = feResp1e->Value;
    feResp1u->Value  = feResp1e->Value / RESP_TTAU;
    p1.hold = feHold1e->Value;
    feHold1u->Value  = feHold1e->Value;
    p1.decay = feDecay1e->Value;
    feDecay1u->Value = feDecay1e->Value / DECAY_TTAU;
    p1.mhold = feMHold1e->Value;
    feMHold1u->Value = feMHold1e->Value;
    p1.fall = feFall1e->Value;
    feFall1u->Value  = feFall1e->Value / FALL_TTAU;
    p1.mfall = feMFall1e->Value;
    feMFall1u->Value = feMFall1e->Value / FALL_TTAU;
    p1.scale = feScale1e->Value * 1000.0;
    feScale1u->Value = feScale1e->Value;

    p2.integ = feInteg2e->Value * 10.0;
    feInteg2u->Value = feInteg2e->Value / INTEG_TTAU;
    p2.resp = feResp2e->Value;
    feResp2u->Value  = feResp2e->Value / RESP_TTAU;
    p2.hold = feHold2e->Value;
    feHold2u->Value  = feHold2e->Value;
    p2.decay = feDecay2e->Value;
    feDecay2u->Value = feDecay2e->Value / DECAY_TTAU;
    p2.mhold = feMHold2e->Value;
    feMHold2u->Value = feMHold2e->Value;
    p2.fall = feFall2e->Value;
    feFall2u->Value  = feFall2e->Value / FALL_TTAU;
    p2.mfall = feMFall2e->Value;
    feMFall2u->Value = feMFall2e->Value / FALL_TTAU;
    p2.scale = feScale2e->Value * 1000.0;
    feScale2u->Value = feScale2e->Value;

    WakePort->SetParams(p1, p2);
    Lock = 0;
  }
}

//---------------------------- ������� Tau: ---------------------------------

void __fastcall TMainForm::feInteg1uChanged(TObject *Sender)
{
  if(!Lock)
  {
    Lock = 1;
    params_t p1, p2;

    feInteg1e->Value = feInteg1u->Value * INTEG_TTAU;
    p1.integ = feInteg1e->Value * 10.0;
    feResp1e->Value = feResp1u->Value * RESP_TTAU;
    p1.resp = feResp1e->Value;
    feHold1e->Value = feHold1u->Value;
    p1.hold = feHold1e->Value;
    feDecay1e->Value = feDecay1u->Value * DECAY_TTAU;
    p1.decay = feDecay1e->Value;
    feMHold1e->Value = feMHold1u->Value;
    p1.mhold = feMHold1e->Value;
    feFall1e->Value = feFall1u->Value * FALL_TTAU;
    p1.fall = feFall1e->Value;
    feMFall1e->Value = feMFall1u->Value * FALL_TTAU;
    p1.mfall = feMFall1e->Value;
    feScale1e->Value = feScale1u->Value;
    p1.scale = feScale1e->Value * 1000.0;

    feInteg2e->Value = feInteg2u->Value * INTEG_TTAU;
    p2.integ = feInteg2e->Value * 10.0;
    feResp2e->Value = feResp2u->Value * RESP_TTAU;
    p2.resp = feResp2e->Value;
    feHold2e->Value = feHold2u->Value;
    p2.hold = feHold2e->Value;
    feDecay2e->Value = feDecay2u->Value * DECAY_TTAU;
    p2.decay = feDecay2e->Value;
    feMHold2e->Value = feMHold2u->Value;
    p2.mhold = feMHold2e->Value;
    feFall2e->Value = feFall2u->Value * FALL_TTAU;
    p2.fall = feFall2e->Value;
    feMFall2e->Value = feMFall2u->Value * FALL_TTAU;
    p2.mfall = feMFall2e->Value;
    feScale2e->Value = feScale2u->Value;
    p2.scale = feScale2e->Value * 1000.0;

    WakePort->SetParams(p1, p2);
    Lock = 0;
  }
}

//----------------------- ���������� ������������: --------------------------

void __fastcall TMainForm::cbLED0Click(TObject *Sender)
{
  if(!Lock)
  {
    int m = cbBrm->ItemIndex;
    int bm = feBrMeter->Value;
    int bs = feBrScale->Value;
    int n = 0;
    if(cbLED0->Checked)  n = n + TR0;
    if(cbLED1->Checked)  n = n + TR1;
    if(cbLED2->Checked)  n = n + TR2;
    if(cbLED3->Checked)  n = n + TR3;
    if(cbLED4->Checked)  n = n + TR4;
    if(cbLED5->Checked)  n = n + TR5;
    if(cbLED6->Checked)  n = n + TR6;
    if(cbLED7->Checked)  n = n + TR7;
    if(cbLED8->Checked)  n = n + TR8;
    if(cbLED9->Checked)  n = n + TR9;
    if(cbScale->Checked) n = n + SCALE;
    FLedsSet = n;
    WakePort->SetLeds(m, bm, bs, n);
  }
}

//---------------------------------------------------------------------------
//------------------------------ �������: -----------------------------------
//---------------------------------------------------------------------------

//------------------------- ���������� �������: -----------------------------

void __fastcall TMainForm::FillTable(void)
{
  for(int i = 0; i < FSegs; i++)
  {
    sgLogTable->Cells[1][i + 1] = Leds[i].en? "Show" : "";
    double dB = Leds[i].dB;
    sgLogTable->Cells[2][i + 1] = FloatToStr(dB);
    uint16_t dBi = (Leds[FSegs - 1].dB - Leds[i].dB) * 100.0;
    Leds[i].code = dB2Code(dBi);
  }
}

//-------------------------- ��������� �������: -----------------------------

void __fastcall TMainForm::sgLogTableDrawCell(TObject *Sender, int ACol,
      int ARow, TRect &Rect, TGridDrawState State)
{
  if(ACol == 1 && ARow > 0)
  {
	  sgLogTable->Canvas->Brush->Color = Colors[Leds[ARow - 1].color];
    AnsiString text = sgLogTable->Cells[1][ARow];
	  sgLogTable->Canvas->TextRect(Rect, Rect.Left + 2, Rect.Top + 2, text);
  }
  FRow  = sgLogTable->Selection.Top;
  FRowE = sgLogTable->Selection.Bottom;
}

//------------------------------- Fill: -------------------------------------

void __fastcall TMainForm::acFillExecute(TObject *Sender)
{
  if(!EnterForm) EnterForm = new TEnterForm(Application);
  if(EnterForm->ShowModal() == mrOk)
  {
    for(int i = FRow; i <= FRowE; i++)
    {
      if(NewColor < COLORS - 1) Leds[i - 1].color = NewColor;
      if(NewEn < 2) Leds[i - 1].en = NewEn;
      if(NewdB > -100) Leds[i - 1].dB = NewdB;
      FillTable();
      DrawScale();
      WriteTable();
    }
  }
}

//---------------------------- Interpolate: ---------------------------------

void __fastcall TMainForm::acInterpolateExecute(TObject *Sender)
{
  if((FRowE != FRow) && (Leds[FRowE - 1].dB > Leds[FRow - 1].dB))
  {
    double Step = (Leds[FRowE - 1].dB - Leds[FRow - 1].dB) / (double)(FRowE - FRow);
    double Value = Leds[FRow - 1].dB;
    for(int i = FRow; i <= FRowE; i++)
    {
      Leds[i - 1].dB = Value;
      Value = Value + Step;
    }
    FillTable();
    DrawScale();
    WriteTable();
  }
}

//-------------------------- Grid Key Press ---------------------------------

void __fastcall TMainForm::sgLogTableKeyPress(TObject *Sender, char &Key)
{
  if(Key == VK_RETURN)
  {
    acFillExecute(NULL);
  }
}

//-------------------------- Double Click: ----------------------------------

void __fastcall TMainForm::sgLogTableDblClick(TObject *Sender)
{
  acFillExecute(NULL);
}

//--------------------------- Write Table: ----------------------------------

void __fastcall TMainForm::WriteTable(void)
{
  int table[SEGS];
  int x = INT16_MIN;
  bool mono = 1;
  for(int i = 0; i < FSegs; i++)
  {
    table[i] = (int)(Leds[i].dB * 100.0 );
    if(table[i] < x) mono = 0;
    x = table[i];
  }
  x = IDYES;
  if(!mono)
  x = MessageDlg("The table is non-monotonic. Write anyway?",
            mtConfirmation, TMsgDlgButtons() << mbYes << mbNo, 0);
  if(x == IDYES) WakePort->SetTable(table);
}

//---------------------------------------------------------------------------
//------------------------------- �����: ------------------------------------
//---------------------------------------------------------------------------

//------------------- ���������� ������� �����������: -----------------------

void __fastcall TMainForm::FillLists(void)
{
  Labels->Add(dBLabel1);  LedsL->Add(Shape1);  LedsR->Add(Shape51);
  Labels->Add(dBLabel2);  LedsL->Add(Shape2);  LedsR->Add(Shape52);
  Labels->Add(dBLabel3);  LedsL->Add(Shape3);  LedsR->Add(Shape53);
  Labels->Add(dBLabel4);  LedsL->Add(Shape4);  LedsR->Add(Shape54);
  Labels->Add(dBLabel5);  LedsL->Add(Shape5);  LedsR->Add(Shape55);
  Labels->Add(dBLabel6);  LedsL->Add(Shape6);  LedsR->Add(Shape56);
  Labels->Add(dBLabel7);  LedsL->Add(Shape7);  LedsR->Add(Shape57);
  Labels->Add(dBLabel8);  LedsL->Add(Shape8);  LedsR->Add(Shape58);
  Labels->Add(dBLabel9);  LedsL->Add(Shape9);  LedsR->Add(Shape59);
  Labels->Add(dBLabel10); LedsL->Add(Shape10); LedsR->Add(Shape60);
  Labels->Add(dBLabel11); LedsL->Add(Shape11); LedsR->Add(Shape61);
  Labels->Add(dBLabel12); LedsL->Add(Shape12); LedsR->Add(Shape62);
  Labels->Add(dBLabel13); LedsL->Add(Shape13); LedsR->Add(Shape63);
  Labels->Add(dBLabel14); LedsL->Add(Shape14); LedsR->Add(Shape64);
  Labels->Add(dBLabel15); LedsL->Add(Shape15); LedsR->Add(Shape65);
  Labels->Add(dBLabel16); LedsL->Add(Shape16); LedsR->Add(Shape66);
  Labels->Add(dBLabel17); LedsL->Add(Shape17); LedsR->Add(Shape67);
  Labels->Add(dBLabel18); LedsL->Add(Shape18); LedsR->Add(Shape68);
  Labels->Add(dBLabel19); LedsL->Add(Shape19); LedsR->Add(Shape69);
  Labels->Add(dBLabel20); LedsL->Add(Shape20); LedsR->Add(Shape70);
  Labels->Add(dBLabel21); LedsL->Add(Shape21); LedsR->Add(Shape71);
  Labels->Add(dBLabel22); LedsL->Add(Shape22); LedsR->Add(Shape72);
  Labels->Add(dBLabel23); LedsL->Add(Shape23); LedsR->Add(Shape73);
  Labels->Add(dBLabel24); LedsL->Add(Shape24); LedsR->Add(Shape74);
  Labels->Add(dBLabel25); LedsL->Add(Shape25); LedsR->Add(Shape75);
  Labels->Add(dBLabel26); LedsL->Add(Shape26); LedsR->Add(Shape76);
  Labels->Add(dBLabel27); LedsL->Add(Shape27); LedsR->Add(Shape77);
  Labels->Add(dBLabel28); LedsL->Add(Shape28); LedsR->Add(Shape78);
  Labels->Add(dBLabel29); LedsL->Add(Shape29); LedsR->Add(Shape79);
  Labels->Add(dBLabel30); LedsL->Add(Shape30); LedsR->Add(Shape80);
  Labels->Add(dBLabel31); LedsL->Add(Shape31); LedsR->Add(Shape81);
  Labels->Add(dBLabel32); LedsL->Add(Shape32); LedsR->Add(Shape82);
  Labels->Add(dBLabel33); LedsL->Add(Shape33); LedsR->Add(Shape83);
  Labels->Add(dBLabel34); LedsL->Add(Shape34); LedsR->Add(Shape84);
  Labels->Add(dBLabel35); LedsL->Add(Shape35); LedsR->Add(Shape85);
  Labels->Add(dBLabel36); LedsL->Add(Shape36); LedsR->Add(Shape86);
  Labels->Add(dBLabel37); LedsL->Add(Shape37); LedsR->Add(Shape87);
  Labels->Add(dBLabel38); LedsL->Add(Shape38); LedsR->Add(Shape88);
  Labels->Add(dBLabel39); LedsL->Add(Shape39); LedsR->Add(Shape89);
  Labels->Add(dBLabel40); LedsL->Add(Shape40); LedsR->Add(Shape90);
  Labels->Add(dBLabel41); LedsL->Add(Shape41); LedsR->Add(Shape91);
  Labels->Add(dBLabel42); LedsL->Add(Shape42); LedsR->Add(Shape92);
  Labels->Add(dBLabel43); LedsL->Add(Shape43); LedsR->Add(Shape93);
  Labels->Add(dBLabel44); LedsL->Add(Shape44); LedsR->Add(Shape94);
  Labels->Add(dBLabel45); LedsL->Add(Shape45); LedsR->Add(Shape95);
  Labels->Add(dBLabel46); LedsL->Add(Shape46); LedsR->Add(Shape96);
  Labels->Add(dBLabel47); LedsL->Add(Shape47); LedsR->Add(Shape97);
  Labels->Add(dBLabel48); LedsL->Add(Shape48); LedsR->Add(Shape98);
  Labels->Add(dBLabel49); LedsL->Add(Shape49); LedsR->Add(Shape99);
  Labels->Add(dBLabel50); LedsL->Add(Shape50); LedsR->Add(Shape100);
}

//---------------------------- ����� �����: ---------------------------------

void __fastcall TMainForm::DrawScale(void)
{
  for(int i = 0; i < SEGS; i++)
  {
    dynamic_cast<TLabel*>(Labels->Items[i])->Caption = FloatToStr(Leds[i].dB);
    dynamic_cast<TLabel*>(Labels->Items[i])->Visible = Leds[i].en && i < FSegs;
    int dx = dynamic_cast<TLabel*>(Labels->Items[i])->Width / 2;
    dynamic_cast<TLabel*>(Labels->Items[i])->Left = 14 + i * 18 - dx;
  }
}

//-------------------------- ������� ������: --------------------------------

void __fastcall TMainForm::ClearMeter(void)
{
  for(int i = 0; i < FSegs; i++)
  {
    TShape *SegL = dynamic_cast<TShape*>(LedsL->Items[i]);
    TShape *SegR = dynamic_cast<TShape*>(LedsR->Items[i]);
    SegL->Brush->Color = Colors[COLORS - 1];
    SegR->Brush->Color = Colors[COLORS - 1];
  }
}

//------------------------- ���������� ������: ------------------------------

void __fastcall TMainForm::UpdateMeter(int *v)
{
  int PeakSegL    = FSegs; int PeakSegR    = FSegs;
  int PeakMaxSegL = FSegs; int PeakMaxSegR = FSegs;
  int BarMaxSegL  = FSegs; int BarMaxSegR  = FSegs;
  BarL     = 0; BarR     = 0;
  PeakL    = 0; PeakR    = 0;
  BarMaxL  = 0; BarMaxR  = 0;
  PeakMaxL = 0; PeakMaxR = 0;

  int i = 0;
  if(FDispMode & DP_BAR)     { BarL     = v[i++]; BarR     = v[i++]; }
  if(FDispMode & DP_PEAK)    { PeakL    = v[i++]; PeakR    = v[i++]; }
  if(FDispMode & DP_BARMAX)  { BarMaxL  = v[i++]; BarMaxR  = v[i++]; }
  if(FDispMode & DP_PEAKMAX) { PeakMaxL = v[i++]; PeakMaxR = v[i++]; }

  for(int i = 0; i < FSegs; i++)
  {
    int dBTab = Leds[i].code;
    TShape *SegL = dynamic_cast<TShape*>(LedsL->Items[i]);
    TShape *SegR = dynamic_cast<TShape*>(LedsR->Items[i]);
    SegL->Brush->Color = (BarL >= dBTab)? Colors[Leds[i].color] : Colors[COLORS - 1];
    SegR->Brush->Color = (BarR >= dBTab)? Colors[Leds[i].color] : Colors[COLORS - 1];
    if(PeakL >= dBTab)    PeakSegL = i;
    if(PeakR >= dBTab)    PeakSegR = i;
    if(PeakMaxL >= dBTab) PeakMaxSegL = i;
    if(PeakMaxR >= dBTab) PeakMaxSegR = i;
    if(BarMaxL >= dBTab)  BarMaxSegL = i;
    if(BarMaxR >= dBTab)  BarMaxSegR = i;
  }
  if((PeakSegL >= 0) && (PeakSegL < FSegs))
    dynamic_cast<TShape*>(LedsL->Items[PeakSegL])->Brush->Color =
      Colors[Leds[PeakSegL].color];
  if((PeakSegR >= 0) && (PeakSegR < FSegs))
    dynamic_cast<TShape*>(LedsR->Items[PeakSegR])->Brush->Color =
      Colors[Leds[PeakSegR].color];
  if((PeakMaxSegL >= 0) && (PeakMaxSegL < FSegs))
    dynamic_cast<TShape*>(LedsL->Items[PeakMaxSegL])->Brush->Color =
      Colors[Leds[PeakMaxSegL].color];
  if((PeakMaxSegR >= 0) && (PeakMaxSegR < FSegs))
    dynamic_cast<TShape*>(LedsR->Items[PeakMaxSegR])->Brush->Color =
      Colors[Leds[PeakMaxSegR].color];
  if((BarMaxSegL >= 0) && (BarMaxSegL < FSegs))
    dynamic_cast<TShape*>(LedsL->Items[BarMaxSegL])->Brush->Color =
      Colors[Leds[BarMaxSegL].color];
  if((BarMaxSegR >= 0) && (BarMaxSegR < FSegs))
    dynamic_cast<TShape*>(LedsR->Items[BarMaxSegR])->Brush->Color =
      Colors[Leds[BarMaxSegR].color];
}

//------------------------- ������� ���� � dB: ------------------------------

double __fastcall TMainForm::Code2dB(int code)
{
  if(code == 0) return(-99.99);
  double ratio = (double)Leds[FSegs - 1].code / code;
  double dB_level = Leds[FSegs - 1].dB - 20.0 * log10(ratio);
  if(dB_level < -99.99) dB_level = -99.99;
  return(dB_level);
}

//-------------------- ����� dB � ������ �������: ---------------------------

void __fastcall TMainForm::DispStatus(void)
{
  if(FDispMode & DP_BAR)
  {
    double Lch = Code2dB(BarL);
    double Rch = Code2dB(BarR);
    StatusBar->Panels->Items[1]->Text = "L: " + FloatToStrF(Lch, ffFixed, 4, 2) + " dB";
    StatusBar->Panels->Items[2]->Text = "R: " + FloatToStrF(Rch, ffFixed, 4, 2) + " dB";
  }
  if(FDispMode & DP_BARMAX)
  {
    double Lch = Code2dB(BarMaxL);
    double Rch = Code2dB(BarMaxR);
    StatusBar->Panels->Items[3]->Text = "L: " + FloatToStrF(Lch, ffFixed, 4, 2) + " dB";
    StatusBar->Panels->Items[4]->Text = "R: " + FloatToStrF(Rch, ffFixed, 4, 2) + " dB";
  }
  if(FDispMode & DP_PEAK)
  {
    double Lch = Code2dB(PeakL);
    double Rch = Code2dB(PeakR);
    StatusBar->Panels->Items[5]->Text = "L: " + FloatToStrF(Lch, ffFixed, 4, 2) + " dB";
    StatusBar->Panels->Items[6]->Text = "R: " + FloatToStrF(Rch, ffFixed, 4, 2) + " dB";
  }
  if(FDispMode & DP_PEAKMAX)
  {
    double Lch = Code2dB(PeakMaxL);
    double Rch = Code2dB(PeakMaxR);
    StatusBar->Panels->Items[7]->Text = "L: " + FloatToStrF(Lch, ffFixed, 4, 2) + " dB";
    StatusBar->Panels->Items[8]->Text = "R: " + FloatToStrF(Rch, ffFixed, 4, 2) + " dB";
  }
}

//---------------------- ������� ������ �������: ----------------------------

void __fastcall TMainForm::ClearStatus(void)
{
  StatusBar->Panels->Items[1]->Text = "";
  StatusBar->Panels->Items[2]->Text = "";
  StatusBar->Panels->Items[3]->Text = "";
  StatusBar->Panels->Items[4]->Text = "";
  StatusBar->Panels->Items[5]->Text = "";
  StatusBar->Panels->Items[6]->Text = "";
  StatusBar->Panels->Items[7]->Text = "";
  StatusBar->Panels->Items[8]->Text = "";
}

//---------------------------------------------------------------------------
//---------------------------- Timer: ---------------------------------------
//---------------------------------------------------------------------------

void __fastcall TMainForm::Timer1Timer(TObject *Sender)
{
  Timer1->Enabled = 0;
  if(FConnected) //���� ���������� ����������
  {
    try
    {
      int p;
      WakePort->GetPreset(p);
      if(FPreset != p)
        acReadExecute(NULL);
      DispStatus();
    }
    catch(const EInOutError &e) { Disconnect(); }
  }
  else
  {
    //�������������� �����������:
    if(FAutoConnect && FPortNumber) Connect();
  }
  Timer1->Enabled = 1;
}

//---------------------------------------------------------------------------
//---------------------- ����� ���������� ������: ---------------------------
//---------------------------------------------------------------------------

//----------------------- ����������� ������: -------------------------------

__fastcall TMeterThread::TMeterThread() : TThread(true)
{
	cs = new TCriticalSection();
  FStarted = false;
  FreeOnTerminate = false;
	TThread::Resume();
}

//------------------------ ���������� ������: -------------------------------

__fastcall TMeterThread::~TMeterThread()
{
	delete cs;
}

//----------------------- �������� ����� ������: ----------------------------

void __fastcall TMeterThread::Execute()
{
  while(!Terminated)
  {
    while(!Terminated && FStarted)
    {
      try
      {
        MainForm->WakePort->GetMeter(FData);
      }
      catch(EInOutError &E) { }
      Synchronize(UpdateMeter);
      Sleep(1);
    }
    Sleep(1);
  }
}

//-------------------- ���������� ������ ����������: ------------------------

void __fastcall TMeterThread::UpdateMeter(void)
{
  if(FStarted)
  {
    MainForm->UpdateMeter(FData);
  }
}

//---------------------- ������/��������� ��������: -------------------------

void __fastcall TMeterThread::SetStarted(bool s)
{
  FStarted = s;
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

//------------------------------- ����: -------------------------------------

void __fastcall TMainForm::btTestClick(TObject *Sender)
{
  uint32_t x;
  WakePort->Test(x);
  edTest->Text = IntToHex((__int64)x, 8);
}

//---------------------------------------------------------------------------



